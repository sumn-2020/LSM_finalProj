package kr.or.ddit.commons.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

public interface PdfCertificateService {
	
	public String createPdf(String keyword);
	
	public MultipartFile createHtmlPdf(String filename, String htmlStr, HttpServletRequest request);
	
}
