package kr.or.ddit.commons.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public interface PdfCertService {
	
	int createHtmlPdf(String filename, String htmlStr, HttpServletRequest request);
	
	
}
