package kr.or.ddit.campus.consult.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *  학사일정 컨트롤러
 * @author 민경진
 *
 */
@Controller
public class CampusConsultController {

	@RequestMapping("/campus/consult")
	public String consult() {
		return "campus/consult";
	}
}
