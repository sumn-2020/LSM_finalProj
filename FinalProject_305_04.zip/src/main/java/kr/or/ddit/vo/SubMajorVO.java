package kr.or.ddit.vo;

import lombok.Data;

@Data
public class SubMajorVO {
	private String subMajorId;
	private Integer credit;
	private String majorId;
	private String semeId;
	private String estaSub;
	private String subjectNm;
	
}
