package kr.or.ddit.emp.majorInfo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *  교직원정보관리 컨트롤러
 * @author 민경진
 *
 */
@Controller
public class MajorInfoController {

	@RequestMapping("/emp/majorInfo")
	public String majorInfo() {
		return "emp/majorInfo/majorInfo";
	}
}
