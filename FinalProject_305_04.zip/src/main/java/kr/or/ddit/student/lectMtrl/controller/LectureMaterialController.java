package kr.or.ddit.student.lectMtrl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 강의자료실 컨트롤러
 * @author 민경진
 *
 */
@Controller
public class LectureMaterialController {

	@RequestMapping("/student/lectMtrl")
	public String lectMtrl() {
		return "student/lectMtrl";
	}
}
